# sorcery

Sorcery est un projet pygame pour aider les élèves à travailler à plusieurs

contributeurs:
AUBERT Sébastien
AUBERT Paul
LucProfit
Hadescsn
AprilWalet
